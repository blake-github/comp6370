#!/usr/bin/python3
import sys
from urllib.parse import unquote
import re
import ast
from pprint import pprint
import math


#Main method, calls other methods to generate output
def main():
    inputNosj = takeInput()
    inputValue = cleanInput(inputNosj)
    outString = ''
    nosType = defineType(inputValue)
    if (nosType == 'num'):
        deNummed = deNum(inputValue)
        outString = getOutputString(nosType, deNummed)
    elif (nosType == 'string'):
        deSimpled = deSimpleString(inputValue)
        outString = getOutputString(nosType, deSimpled)
    elif (nosType == 'complex string'):
        deComplexed = deComplexString(inputValue)
        outString = getOutputString(nosType, deComplexed)
    elif (nosType == 'map'):
        deMapped = {}
        deMapped = deMap(inputValue)
        if (deMapped == None):
            return
        outString = getOutputString(nosType, deMapped)
    sys.stdout.write(outString)
    
#Reads in the input file from the command line
#and opens the file to get the data
def takeInput():
    commandLine = ''
    nosj = ''
    try:
        commandLine = sys.argv[1]
    except:
        sys.stderr.write('ERROR -- Please try a different input\n')
        sys.exit(66)
    
    if (commandLine == ''):
        sys.stderr.write('ERROR -- Please input a file\n')
        sys.exit(66)  
    else:
        try:
            f = open(commandLine)
        except FileNotFoundError:
            sys.stderr.write('ERROR -- File not found\n')
            sys.exit(66)  
        with open(commandLine, 'r') as my_file:
            nosj = my_file.read()
            if ('\n\n' in nosj):
                sys.stderr.write('ERROR -- Invalid input due to a newline\n')
                sys.exit(66)  
            if (nosj.strip() == ''):
                sys.stderr.write('ERROR -- No input found in file\n')
                sys.exit(66)
            
    return nosj
    
#Determines the nosj data type of the input
def defineType(inNos):
    typeOf = ''
    if (inNos[0] == 'f' and inNos[-1] == 'f' and inNos[-2].isdigit()):
        typeOf = 'num'
        return typeOf
    elif (inNos.find('%') == -1 and inNos[-1] == 's'):
        typeOf = 'string'
        return typeOf
    elif (inNos[0] == '<' or inNos[0] == '{'):
        typeOf = 'map'
        return typeOf
    elif (inNos.find('%') != -1 and inNos[-1] != ' '):
        typeOf = 'complex string'
        return typeOf
    #Error throws if nosj data is invalid
    else:
        sys.stderr.write('ERROR -- Invalid data\n')
        sys.exit(66)
    
    return typeOf

#Strip and leading or trailing whitespace
def cleanInput(dirtyInput):
    cleaned = dirtyInput.strip()
    return cleaned
 
#Turn nosj num into plain text   
def deNum(inNum):
    outNum = ''
    outNum = inNum[:-1]
    outNum = outNum[1:]
    if (outNum.find(' ') != -1):
        sys.stderr.write('ERROR -- Invalid nosj number\n')
        sys.exit(66)
    outNum = float(outNum)
    return outNum

#Turn simple string into plain text
def deSimpleString(inSimpleString):
    outSimpleString = ''
    outSimpleString = inSimpleString[:-1]
    return outSimpleString

#Decode complex string to plain text
def deComplexString(inComplexString):
    outComplex = ''
    outComplex = unquote(inComplexString)
    return outComplex
    
#Converts map data structure into a python dictionary
#To set up for easier parsing later
def deMap(inputMap):
   split = re.split('[:]', inputMap)
   if (len(split) == 1):
       if(split[0].find(' ') != -1):
           sys.stderr.write('ERROR -- Invalid spaces in map\n')
           sys.exit(66)
   if (len(split) == 1):
       if(inputMap.count('>') > 2 or inputMap.count('<') > 2):
           sys.stderr.write('ERROR -- Invalid map\n')
           sys.exit(66)
       return {}
   mapCheckClean = split[1].strip()
   trimmed = ''
   c = ','
   s = inputMap
   commaSpace = [pos for pos, char in enumerate(s) if char == c]
   for commaIndex in commaSpace:
       #Error check for spaces near commans
       if (inputMap[commaIndex - 1] == ' ' or inputMap[commaIndex + 1] == ' '):
           sys.stderr.write('ERROR -- Invalid spaces in map (around comma)\n')
           sys.exit(66)
   for i in range(len(split)):
       split[i] = split[i].replace('<<', '')
       split[i] = split[i].replace('>>', '')
       #Error check for invalid spaces
       if(bool(re.search(r'^\s+|\s+$', split[i]))):
            sys.stderr.write('ERROR -- Invalid spaces in map\n')
            sys.exit(66)
       
   inputMap = inputMap.replace('<<', '{')
   inputMap = inputMap.replace('>>', '}')
   s = inputMap
   s = re.sub(r':\s?(?![{\[\s])([^,}]+)', r': "\1"', s)
   s = re.sub(r'(\w+):', r'"\1":', s)
   
   #Small helper method to add quotes into map structure
   def add_quotes_to_lists(match):
       return re.sub(r'([\s\[])([^\],]+)', r'\1"\2"', match.group(0))

   s = re.sub(r'\[[^\]]+', add_quotes_to_lists, s) #Add quotes to list items
   s = s.replace('\"', '\'')
   try:
       split = ast.literal_eval(s)
   except:
       #Throw error if the string can't be
       #turned into dictionary
       sys.stderr.write('ERROR -- Invalid input\n')
       sys.exit(66)
   #Error check for invalid brackets
   if (s.find('<') != -1 or s.find('>') != -1):
       sys.stderr.write('ERROR -- Invalid input\n')
       sys.exit(66)
   #Error check for duplicate keys
   originalString = removeSpaceNoQuotes(s)
   convertBack = removeSpaceNoQuotes(str(split))
   if (originalString != convertBack):
           sys.stderr.write('ERROR -- Invalid map (possibly duplicate keys)\n')
           sys.exit(66)
   return split
#Removes spaces from strings to compare
#used for checking for duplicate keys
def removeSpaceNoQuotes(inputString):
    result = []
    inside_quotes = False

    for char in inputString:
        if char == '"':
            inside_quotes = not inside_quotes
        if char != ' ' or inside_quotes:
            result.append(char)

    return ''.join(result)
    
#Gets the string that is needed to output to the user
#Still used, but to a much less degree because
#I didn't anticipate that all valid input would
#Come in as a map
def getOutputString(typeOf, value):
    outputString = 'key-name -- type -- value\n'
    if (isinstance(value, float)):
        if value.is_integer():
            value = math.trunc(value)
        else:
            value = value
    if (typeOf == 'map'):
        outputString = ''
        last = None
        #printDict(value, last)
        newPrintDict(value)
        return outputString
    outputString = ''
    return outputString

#Prints out the nosj map in correct formatting using recursion
def newPrintDict(dictionary, bounds_stack=None):
    if bounds_stack is None:
        bounds_stack = []

    sys.stdout.write('begin-map\n')
    
    for index, (key, value) in enumerate(dictionary.items()):
        current_bounds_stack = bounds_stack + [index]
        vType = defineType(str(value))
        if (vType == 'num'):
            value = deNum(value)
            if value.is_integer():
                value = math.trunc(value)
        elif (vType == 'string'):
            value = deSimpleString(value)
        elif (vType == 'complex string'):
            vType = 'string'
            value = deComplexString(str(value))
        if (vType == '' or vType == 'map'):
            sys.stdout.write(key + ' -- ' + 'map -- \n')
        else:
            sys.stdout.write(key + ' -- ' + vType)
        
        if isinstance(value, dict):
            newPrintDict(value, current_bounds_stack)
        else:
            sys.stdout.write(' -- ' + str(value) + '\n')

    sys.stdout.write("end-map\n")


#This method is now unused due to me thinking I had
#to keep track of the index of each key like the spec showed

#Leaving this method for my reference, do not use
def printDict(d, index_stack = None, indent = 0):
    res = ""
    if index_stack is None:
        index_stack = []
    for index, (key, value) in enumerate(d.items()):
        current_index_stack = index_stack + [index]
        if isinstance(value, dict):
            stringCurrent = ''
            for indexValue in current_index_stack:
                stringCurrent += '-' + str(indexValue + 1)
            sys.stdout.write(key)
            printDict(value, current_index_stack, indent + 1)
        else:
            stringCurrent = ''
            for indexValue in current_index_stack:
                stringCurrent += '-' + str(indexValue + 1)
            if (len(current_index_stack) > 0):
                sys.stdout.write(' -- map\n' + 'begin-map\n') 
            sys.stdout.write(key)
            vType = defineType(value)
            if (vType == 'num'):
                value = deNum(value)
                if value % 1 == 0:
                    value = int(value)
            elif (vType == 'string'):
                value = deSimpleString(value)
            elif (vType == 'complex string'):
                vType = 'string'
                value = deComplexString(value)
            sys.stdout.write(' -- ' + vType + ' -- ' + str(value) + '\n' + 'end-map\n')
    return res

    
    
#Call main method to run the code
main()
    
