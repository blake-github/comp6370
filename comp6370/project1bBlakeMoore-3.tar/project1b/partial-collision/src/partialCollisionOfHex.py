#!/usr/bin/python3
import hashlib
import random
import string
import sys

prefix = 'bmm0066@auburn.edu'
otherPrefix = 'bmm'
tryingPrefix = otherPrefix.encode('utf-8') + b'\x00'
target_prefix_bytes = prefix.encode('utf-8')

found_collisions = []

while len(found_collisions) < 2:
    #Add a random suffix of random length
    random_suffix = ''.join(random.choices(string.ascii_letters + string.digits, k = random.randrange(1, 50)))
    
    input_data = target_prefix_bytes + random_suffix.encode('utf-8')
    
    # Get the SHA-256 digest
    hash_obj = hashlib.sha256()
    hash_obj.update(input_data)
    hash_value = hash_obj.digest()
    
    # Check if the first four bytes match the target prefix
    if hash_value[:4] == tryingPrefix[:4]:
        # print("Partial SHA-256 collision found!")
        # print("Input:", input_data.decode('utf-8'))
        # print("Hash:", hash_obj.hexdigest())
        # print('Input Hex:', input_data)
        # print('Hash Hex:', hash_value)
        sys.stdout.write(input_data.decode('utf-8') + '\n')
        found_collisions.append((input_data.decode('utf-8'), hash_obj.hexdigest()))

#Makes sure to exit with status code 0
sys.exit(0)
