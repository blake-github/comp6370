import sys
#Pass name and grade to be printed
print('bmm0066\x00 AA+')
